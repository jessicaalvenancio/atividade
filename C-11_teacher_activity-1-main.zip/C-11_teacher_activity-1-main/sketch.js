var marks = [30,40,45,35];


function media_matriz(){
var soma = 0;
for (var j = 0; j < marks.length; j = j +1){
 soma = soma + marks[j];
}

var media = soma/marks.length;
console.log(media);
}



function setup() {
  createCanvas(400, 400);
  media_matriz();
}

function draw() {
  background(150);
}